<?php
/**
 * This file has been left empty on purpose.
 * It is required by WordPress for the theme to activates.
 *
 * @link https://core.trac.wordpress.org/ticket/54272
 *
 * @package estory
 * @since 1.0.0
 */
